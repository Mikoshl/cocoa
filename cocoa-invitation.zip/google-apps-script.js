/**
 * Этот код нужно вставить в script.google.com.
 * Таблица получит колонки: Дата, Ответ, Время, Какао, Пожелания.
 */

const SHEET_NAME = "Ответы";

function doPost(e) {
  try {
    const sheet = getOrCreateSheet_();
    const data = JSON.parse(e.postData.contents);

    sheet.appendRow([
      new Date(),
      sanitize_(data.answer),
      sanitize_(data.pickupTime),
      sanitize_(data.cocoa),
      sanitize_(data.wishes),
    ]);

    return ContentService
      .createTextOutput(JSON.stringify({ ok: true }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (error) {
    return ContentService
      .createTextOutput(JSON.stringify({ ok: false, error: String(error) }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function getOrCreateSheet_() {
  const spreadsheet = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = spreadsheet.getSheetByName(SHEET_NAME);

  if (!sheet) {
    sheet = spreadsheet.insertSheet(SHEET_NAME);
  }

  if (sheet.getLastRow() === 0) {
    sheet.appendRow(["Дата", "Ответ", "Время заезда", "Какао", "Пожелания"]);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, 5).setFontWeight("bold").setBackground("#f7dfcc");
    sheet.autoResizeColumns(1, 5);
  }

  return sheet;
}

// Не даёт значению из формы превратиться в формулу Google Sheets.
function sanitize_(value) {
  const text = String(value ?? "");
  return /^[=+\-@]/.test(text) ? `'${text}` : text;
}
